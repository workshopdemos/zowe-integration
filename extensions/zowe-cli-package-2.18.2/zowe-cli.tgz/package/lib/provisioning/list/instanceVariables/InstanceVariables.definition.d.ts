import { ICommandDefinition } from "@zowe/imperative";
export declare const instanceVariables: ICommandDefinition;
//# sourceMappingURL=InstanceVariables.definition.d.ts.map