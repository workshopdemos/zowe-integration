import { ICommandDefinition } from "@zowe/imperative";
export declare const instanceInfo: ICommandDefinition;
//# sourceMappingURL=InstanceInfo.definition.d.ts.map