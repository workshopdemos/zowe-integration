import { ICommandDefinition } from "@zowe/imperative";
export declare const registryInstances: ICommandDefinition;
//# sourceMappingURL=RegistryInstances.definition.d.ts.map