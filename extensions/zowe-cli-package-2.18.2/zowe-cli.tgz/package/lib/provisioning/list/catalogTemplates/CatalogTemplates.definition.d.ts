import { ICommandDefinition } from "@zowe/imperative";
export declare const catalogTemplates: ICommandDefinition;
//# sourceMappingURL=CatalogTemplates.definition.d.ts.map