import { ICommandDefinition } from "@zowe/imperative";
export declare const ListCommand: ICommandDefinition;
//# sourceMappingURL=List.definition.d.ts.map