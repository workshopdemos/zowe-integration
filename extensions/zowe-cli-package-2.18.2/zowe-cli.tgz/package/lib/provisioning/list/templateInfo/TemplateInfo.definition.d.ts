import { ICommandDefinition } from "@zowe/imperative";
export declare const templateInfo: ICommandDefinition;
//# sourceMappingURL=TemplateInfo.definition.d.ts.map