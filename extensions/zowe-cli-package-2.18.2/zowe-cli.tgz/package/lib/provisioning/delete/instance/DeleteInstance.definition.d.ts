import { ICommandDefinition } from "@zowe/imperative";
export declare const DeleteInstanceDefinition: ICommandDefinition;
//# sourceMappingURL=DeleteInstance.definition.d.ts.map