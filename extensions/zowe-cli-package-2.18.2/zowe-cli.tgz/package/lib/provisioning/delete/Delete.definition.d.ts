import { ICommandDefinition } from "@zowe/imperative";
export declare const DeleteCommand: ICommandDefinition;
//# sourceMappingURL=Delete.definition.d.ts.map