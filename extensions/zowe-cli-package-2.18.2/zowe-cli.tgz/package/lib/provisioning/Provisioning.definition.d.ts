import { ICommandDefinition } from "@zowe/imperative";
declare const definition: ICommandDefinition;
export = definition;
//# sourceMappingURL=Provisioning.definition.d.ts.map