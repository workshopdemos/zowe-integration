import { ICommandDefinition } from "@zowe/imperative";
export declare const ActionDefinition: ICommandDefinition;
//# sourceMappingURL=Action.definition.d.ts.map