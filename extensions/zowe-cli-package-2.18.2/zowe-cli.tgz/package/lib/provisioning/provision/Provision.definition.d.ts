import { ICommandDefinition } from "@zowe/imperative";
export declare const ProvisionCommand: ICommandDefinition;
//# sourceMappingURL=Provision.definition.d.ts.map