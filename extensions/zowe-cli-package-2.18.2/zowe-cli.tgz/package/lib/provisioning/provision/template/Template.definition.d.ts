import { ICommandDefinition } from "@zowe/imperative";
export declare const TemplateDefinition: ICommandDefinition;
//# sourceMappingURL=Template.definition.d.ts.map