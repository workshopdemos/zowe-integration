import { ICommandDefinition } from "@zowe/imperative";
declare const definition: ICommandDefinition;
export = definition;
//# sourceMappingURL=Zosmf.definition.d.ts.map