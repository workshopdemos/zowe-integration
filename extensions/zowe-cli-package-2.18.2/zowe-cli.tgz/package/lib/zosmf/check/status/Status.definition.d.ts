import { ICommandDefinition } from "@zowe/imperative";
export declare const StatusDefinition: ICommandDefinition;
//# sourceMappingURL=Status.definition.d.ts.map