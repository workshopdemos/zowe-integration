import { ICommandDefinition } from "@zowe/imperative";
export declare const CheckCommand: ICommandDefinition;
//# sourceMappingURL=Check.definition.d.ts.map