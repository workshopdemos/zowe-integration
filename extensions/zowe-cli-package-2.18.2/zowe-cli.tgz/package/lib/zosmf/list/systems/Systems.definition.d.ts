import { ICommandDefinition } from "@zowe/imperative";
export declare const SystemsDefinition: ICommandDefinition;
//# sourceMappingURL=Systems.definition.d.ts.map