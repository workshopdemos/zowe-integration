import { ICommandDefinition } from "@zowe/imperative";
export declare const definition: ICommandDefinition;
//# sourceMappingURL=ZosConsole.definition.d.ts.map