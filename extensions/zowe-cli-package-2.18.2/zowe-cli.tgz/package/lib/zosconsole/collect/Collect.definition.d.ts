import { ICommandDefinition } from "@zowe/imperative";
export declare const CollectCommand: ICommandDefinition;
//# sourceMappingURL=Collect.definition.d.ts.map