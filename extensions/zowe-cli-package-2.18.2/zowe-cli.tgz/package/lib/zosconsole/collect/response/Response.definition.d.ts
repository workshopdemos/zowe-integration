import { ICommandDefinition } from "@zowe/imperative";
export declare const SyncResponseCommandDefinition: ICommandDefinition;
//# sourceMappingURL=Response.definition.d.ts.map