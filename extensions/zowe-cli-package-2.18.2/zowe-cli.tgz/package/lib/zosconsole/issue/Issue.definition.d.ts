import { ICommandDefinition } from "@zowe/imperative";
export declare const IssueCommand: ICommandDefinition;
//# sourceMappingURL=Issue.definition.d.ts.map