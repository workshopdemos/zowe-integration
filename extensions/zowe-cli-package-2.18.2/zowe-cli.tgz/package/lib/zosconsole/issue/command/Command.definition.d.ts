import { ICommandDefinition } from "@zowe/imperative";
export declare const IssueCommandDefinition: ICommandDefinition;
//# sourceMappingURL=Command.definition.d.ts.map