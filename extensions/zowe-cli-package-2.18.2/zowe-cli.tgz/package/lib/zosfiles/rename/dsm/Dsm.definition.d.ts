import { ICommandDefinition } from "@zowe/imperative";
export declare const DsmDefinition: ICommandDefinition;
//# sourceMappingURL=Dsm.definition.d.ts.map