import { ICommandDefinition } from "@zowe/imperative";
/**
 * Compare local files and data sets command definition containing its description, examples and/or options
 * @type {ICommandDefinition}
 */
export declare const LocalfileUssFileDefinition: ICommandDefinition;
//# sourceMappingURL=LocalfileUss.definition.d.ts.map