import { ICommandDefinition } from "@zowe/imperative";
/**
 * Download group definition containing its description and children
 * @type {ICommandDefinition}
 */
export declare const ListDefinition: ICommandDefinition;
//# sourceMappingURL=List.definition.d.ts.map