import { ICommandDefinition } from "@zowe/imperative";
/**
 * List data sets command definition containing its description, examples and/or options
 * @type {ICommandDefinition}
 */
export declare const FsDefinition: ICommandDefinition;
//# sourceMappingURL=Fs.definition.d.ts.map