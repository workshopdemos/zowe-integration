import { ICommandDefinition } from "@zowe/imperative";
/**
 * List all members command definition containing its description, examples and/or options
 * @type {ICommandDefinition}
 */
export declare const USSFileDefinition: ICommandDefinition;
//# sourceMappingURL=UssFile.definition.d.ts.map