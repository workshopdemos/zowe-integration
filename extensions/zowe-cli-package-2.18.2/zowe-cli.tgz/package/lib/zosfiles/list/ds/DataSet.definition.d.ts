import { ICommandDefinition } from "@zowe/imperative";
/**
 * List data sets command definition containing its description, examples and/or options
 * @type {ICommandDefinition}
 */
export declare const DataSetDefinition: ICommandDefinition;
//# sourceMappingURL=DataSet.definition.d.ts.map