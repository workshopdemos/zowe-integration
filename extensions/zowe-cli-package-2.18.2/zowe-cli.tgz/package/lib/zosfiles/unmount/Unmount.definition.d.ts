import { ICommandDefinition } from "@zowe/imperative";
/**
 * Download group definition containing its description and children
 * @type {ICommandDefinition}
 */
export declare const UnmountDefinition: ICommandDefinition;
//# sourceMappingURL=Unmount.definition.d.ts.map