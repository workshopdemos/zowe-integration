import { ICommandDefinition } from "@zowe/imperative";
/**
 * Create C-code PDS command definition containing its description, examples and/or options
 * @type {ICommandDefinition}
 */
export declare const CPDSDefinition: ICommandDefinition;
//# sourceMappingURL=CPDS.definition.d.ts.map