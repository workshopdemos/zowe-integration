import { ICommandDefinition } from "@zowe/imperative";
export declare const UssDirDefinition: ICommandDefinition;
//# sourceMappingURL=ussDir.definition.d.ts.map