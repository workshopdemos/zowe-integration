import { ICommandDefinition } from "@zowe/imperative";
export declare const VsamDefinition: ICommandDefinition;
//# sourceMappingURL=vsam.definition.d.ts.map