import { ICommandDefinition } from "@zowe/imperative";
export declare const UssFileDefinition: ICommandDefinition;
//# sourceMappingURL=ussFile.definition.d.ts.map