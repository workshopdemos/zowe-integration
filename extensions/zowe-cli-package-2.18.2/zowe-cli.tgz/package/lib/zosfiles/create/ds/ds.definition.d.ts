import { ICommandDefinition } from "@zowe/imperative";
/**
 * Create dataSet command definition containing its description, examples and/or options
 * @type {ICommandDefinition}
 */
export declare const DsDefinition: ICommandDefinition;
//# sourceMappingURL=ds.definition.d.ts.map