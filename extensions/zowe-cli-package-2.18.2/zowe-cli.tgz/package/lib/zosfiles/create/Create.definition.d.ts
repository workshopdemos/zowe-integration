import { ICommandDefinition } from "@zowe/imperative";
/**
 * Create group definition containing its description and children
 * @type {ICommandDefinition}
 */
export declare const CreateDefinition: ICommandDefinition;
//# sourceMappingURL=Create.definition.d.ts.map