import { ICommandDefinition } from "@zowe/imperative";
/**
 * Create PDS command definition containing its description, examples and/or options
 * @type {ICommandDefinition}
 */
export declare const PdsDefinition: ICommandDefinition;
//# sourceMappingURL=Pds.definition.d.ts.map