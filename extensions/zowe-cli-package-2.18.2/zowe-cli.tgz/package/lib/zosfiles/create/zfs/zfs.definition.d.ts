import { ICommandDefinition } from "@zowe/imperative";
export declare const ZfsDefinition: ICommandDefinition;
//# sourceMappingURL=zfs.definition.d.ts.map