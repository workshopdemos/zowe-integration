import { ICommandDefinition } from "@zowe/imperative";
/**
 * View USS file content command definition containing its description, examples and/or options
 * @type {ICommandDefinition}
 */
export declare const USSFileDefinition: ICommandDefinition;
//# sourceMappingURL=USSFile.definition.d.ts.map