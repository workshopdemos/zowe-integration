import { ICommandDefinition } from "@zowe/imperative";
export declare const FsDefinition: ICommandDefinition;
//# sourceMappingURL=fs.definition.d.ts.map