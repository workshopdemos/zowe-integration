import { ICommandOptionDefinition } from "@zowe/imperative";
export declare const ZosFilesOptionDefinitions: ICommandOptionDefinition[];
//# sourceMappingURL=ZosFiles.options.d.ts.map