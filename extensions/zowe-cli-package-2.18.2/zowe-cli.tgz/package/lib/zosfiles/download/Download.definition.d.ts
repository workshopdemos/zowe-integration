import { ICommandDefinition } from "@zowe/imperative";
/**
 * Download group definition containing its description and children
 * @type {ICommandDefinition}
 */
export declare const DownloadDefinition: ICommandDefinition;
//# sourceMappingURL=Download.definition.d.ts.map