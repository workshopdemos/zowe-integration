import { ICommandDefinition } from "@zowe/imperative";
/**
 * Download all members command definition containing its description, examples and/or options
 * @type {ICommandDefinition}
 */
export declare const DataSetMatchingDefinition: ICommandDefinition;
//# sourceMappingURL=DataSetMatching.definition.d.ts.map