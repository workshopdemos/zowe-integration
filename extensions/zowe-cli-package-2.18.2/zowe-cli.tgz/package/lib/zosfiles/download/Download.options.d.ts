import { ICommandOptionDefinition } from "@zowe/imperative";
/**
 * Object containing all options to be used by the Download data set API
 */
export declare const DownloadOptions: {
    [key: string]: ICommandOptionDefinition;
};
//# sourceMappingURL=Download.options.d.ts.map