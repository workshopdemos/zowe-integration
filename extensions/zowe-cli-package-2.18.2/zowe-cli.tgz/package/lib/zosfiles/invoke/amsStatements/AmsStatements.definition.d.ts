import { ICommandDefinition } from "@zowe/imperative";
/**
 * AMS command definition containing its description, examples and/or options
 * @type {ICommandDefinition}
 */
export declare const AmsStatementsDefinition: ICommandDefinition;
//# sourceMappingURL=AmsStatements.definition.d.ts.map