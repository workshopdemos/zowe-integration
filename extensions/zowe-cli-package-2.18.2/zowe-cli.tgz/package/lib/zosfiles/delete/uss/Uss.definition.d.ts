import { ICommandDefinition } from "@zowe/imperative";
/**
 * This object defines the command for delete data-set within zosfiles. This is not
 * something that is intended to be used outside of the zosfiles package.
 *
 * @private
 */
export declare const UssDefinition: ICommandDefinition;
//# sourceMappingURL=Uss.definition.d.ts.map