import { ICommandDefinition } from "@zowe/imperative";
export declare const MdsDefinition: ICommandDefinition;
//# sourceMappingURL=Mds.definition.d.ts.map