import { ICommandDefinition } from "@zowe/imperative";
export declare const DsDefinition: ICommandDefinition;
//# sourceMappingURL=Ds.definition.d.ts.map