import { ICommandDefinition } from "@zowe/imperative";
/**
 * Edit USS file content command definition containing its description, examples and/or options
 * @type {ICommandDefinition}
 */
export declare const USSFileDefinition: ICommandDefinition;
//# sourceMappingURL=USSFile.definition.d.ts.map