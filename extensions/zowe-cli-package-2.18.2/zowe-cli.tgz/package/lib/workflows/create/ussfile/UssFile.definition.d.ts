import { ICommandDefinition } from "@zowe/imperative";
/**
 * This object defines the command for creating workflow instance from uss file within zosworkflows.
 * This is not something that is intended to be used outside of this npm package.
 *
 * @private
 */
export declare const UssFile: ICommandDefinition;
//# sourceMappingURL=UssFile.definition.d.ts.map