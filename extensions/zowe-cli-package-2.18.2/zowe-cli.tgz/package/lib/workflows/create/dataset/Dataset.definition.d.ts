import { ICommandDefinition } from "@zowe/imperative";
/**
 * This object defines the command for creating workflow instance from dataset within zosworkflows.
 * This is not something that is intended to be used outside of this npm package.
 *
 * @private
 */
export declare const DataSet: ICommandDefinition;
//# sourceMappingURL=Dataset.definition.d.ts.map