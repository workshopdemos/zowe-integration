import { ICommandDefinition } from "@zowe/imperative";
export declare const definition: ICommandDefinition;
//# sourceMappingURL=ZosLogs.definition.d.ts.map