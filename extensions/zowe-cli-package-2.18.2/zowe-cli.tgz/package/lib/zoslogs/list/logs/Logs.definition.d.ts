import { ICommandDefinition } from "@zowe/imperative";
export declare const LogsDefinition: ICommandDefinition;
//# sourceMappingURL=Logs.definition.d.ts.map