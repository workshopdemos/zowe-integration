import { ICommandDefinition } from "@zowe/imperative";
export declare const JobDefinition: ICommandDefinition;
//# sourceMappingURL=Job.definition.d.ts.map