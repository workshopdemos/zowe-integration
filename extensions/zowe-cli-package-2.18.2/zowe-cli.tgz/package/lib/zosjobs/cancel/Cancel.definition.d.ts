import { ICommandDefinition } from "@zowe/imperative";
export declare const CancelDefinition: ICommandDefinition;
//# sourceMappingURL=Cancel.definition.d.ts.map