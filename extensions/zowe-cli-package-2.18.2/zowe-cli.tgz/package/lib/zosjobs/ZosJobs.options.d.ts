import { ICommandOptionDefinition } from "@zowe/imperative";
export declare const ZosJobsOptions: {
    [key: string]: ICommandOptionDefinition;
};
//# sourceMappingURL=ZosJobs.options.d.ts.map