import { ICommandDefinition } from "@zowe/imperative";
export declare const ModifyDefinition: ICommandDefinition;
//# sourceMappingURL=Modify.definition.d.ts.map