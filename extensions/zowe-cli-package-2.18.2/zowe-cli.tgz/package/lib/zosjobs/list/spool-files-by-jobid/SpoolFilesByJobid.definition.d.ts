import { ICommandDefinition } from "@zowe/imperative";
export declare const SpoolFilesByJobidDefinition: ICommandDefinition;
//# sourceMappingURL=SpoolFilesByJobid.definition.d.ts.map