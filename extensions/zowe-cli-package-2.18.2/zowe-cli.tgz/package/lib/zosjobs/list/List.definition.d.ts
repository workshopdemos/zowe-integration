import { ICommandDefinition } from "@zowe/imperative";
export declare const ListDefinition: ICommandDefinition;
//# sourceMappingURL=List.definition.d.ts.map