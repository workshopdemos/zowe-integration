import { ICommandDefinition } from "@zowe/imperative";
export declare const JobsDefinition: ICommandDefinition;
//# sourceMappingURL=Jobs.definition.d.ts.map