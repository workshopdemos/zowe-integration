import { ICommandDefinition } from "@zowe/imperative";
export declare const DownloadDefinition: ICommandDefinition;
//# sourceMappingURL=Download.definition.d.ts.map