import { ICommandDefinition } from "@zowe/imperative";
export declare const OutputDefinition: ICommandDefinition;
//# sourceMappingURL=Output.definition.d.ts.map