import { ICommandDefinition } from "@zowe/imperative";
export declare const OldJobsDefinition: ICommandDefinition;
//# sourceMappingURL=OldJobs.definition.d.ts.map