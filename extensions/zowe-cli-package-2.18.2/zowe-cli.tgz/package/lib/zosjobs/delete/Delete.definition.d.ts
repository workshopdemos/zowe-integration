import { ICommandDefinition } from "@zowe/imperative";
export declare const DeleteDefinition: ICommandDefinition;
//# sourceMappingURL=Delete.definition.d.ts.map