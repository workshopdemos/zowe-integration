import { ICommandDefinition } from "@zowe/imperative";
export declare const definition: ICommandDefinition;
//# sourceMappingURL=ZosJobs.definition.d.ts.map