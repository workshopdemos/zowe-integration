import { ICommandDefinition } from "@zowe/imperative";
export declare const USSFileDefinition: ICommandDefinition;
//# sourceMappingURL=USSFile.definition.d.ts.map