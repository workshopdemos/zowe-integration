import { ICommandDefinition } from "@zowe/imperative";
export declare const DataSetDefinition: ICommandDefinition;
//# sourceMappingURL=DataSet.definition.d.ts.map