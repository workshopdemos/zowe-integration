import { ICommandDefinition } from "@zowe/imperative";
export declare const LocalFileDefinition: ICommandDefinition;
//# sourceMappingURL=localFile.definition.d.ts.map