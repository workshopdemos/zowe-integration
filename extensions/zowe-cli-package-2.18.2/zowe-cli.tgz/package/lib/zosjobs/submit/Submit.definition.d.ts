import { ICommandDefinition } from "@zowe/imperative";
export declare const SubmitDefinition: ICommandDefinition;
//# sourceMappingURL=Submit.definition.d.ts.map