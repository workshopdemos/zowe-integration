import { ICommandDefinition } from "@zowe/imperative";
export declare const StdinDefinition: ICommandDefinition;
//# sourceMappingURL=stdin.definition.d.ts.map