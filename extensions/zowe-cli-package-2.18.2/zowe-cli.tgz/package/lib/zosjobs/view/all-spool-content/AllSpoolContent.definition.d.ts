import { ICommandDefinition } from "@zowe/imperative";
export declare const AllSpoolContentDefinition: ICommandDefinition;
//# sourceMappingURL=AllSpoolContent.definition.d.ts.map