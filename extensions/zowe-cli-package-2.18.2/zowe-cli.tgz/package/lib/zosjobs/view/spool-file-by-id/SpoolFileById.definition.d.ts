import { ICommandDefinition } from "@zowe/imperative";
export declare const SpoolFileByIdDefinition: ICommandDefinition;
//# sourceMappingURL=SpoolFileById.definition.d.ts.map