import { ICommandDefinition } from "@zowe/imperative";
export declare const ViewDefinition: ICommandDefinition;
//# sourceMappingURL=View.definition.d.ts.map