import { ICommandDefinition } from "@zowe/imperative";
export declare const JobStatusByJobidDefinition: ICommandDefinition;
//# sourceMappingURL=JobStatusByJobid.definition.d.ts.map