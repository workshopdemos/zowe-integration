import { ICommandDefinition } from "@zowe/imperative";
export declare const StopCommand: ICommandDefinition;
//# sourceMappingURL=Stop.definition.d.ts.map