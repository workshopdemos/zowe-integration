import { ICommandDefinition } from "@zowe/imperative";
export declare const SendToAddressSpaceCommandDefinition: ICommandDefinition;
//# sourceMappingURL=SendToAddressSpace.definition.d.ts.map