import { ICommandDefinition } from "@zowe/imperative";
export declare const SendCommand: ICommandDefinition;
//# sourceMappingURL=Send.definition.d.ts.map