import { ICommandDefinition } from "@zowe/imperative";
export declare const PingCommand: ICommandDefinition;
//# sourceMappingURL=Ping.definition.d.ts.map