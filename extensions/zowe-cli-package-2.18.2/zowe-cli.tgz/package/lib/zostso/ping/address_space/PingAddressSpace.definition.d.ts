import { ICommandDefinition } from "@zowe/imperative";
export declare const PingAddressSpaceCommandDefinition: ICommandDefinition;
//# sourceMappingURL=PingAddressSpace.definition.d.ts.map