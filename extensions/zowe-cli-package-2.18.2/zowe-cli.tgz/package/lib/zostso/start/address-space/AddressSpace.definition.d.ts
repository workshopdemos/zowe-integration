import { ICommandDefinition } from "@zowe/imperative";
export declare const AddressSpaceDefinition: ICommandDefinition;
//# sourceMappingURL=AddressSpace.definition.d.ts.map