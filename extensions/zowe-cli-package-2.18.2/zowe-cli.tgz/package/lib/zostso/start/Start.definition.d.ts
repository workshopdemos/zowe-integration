import { ICommandDefinition } from "@zowe/imperative";
export declare const StartCommand: ICommandDefinition;
//# sourceMappingURL=Start.definition.d.ts.map