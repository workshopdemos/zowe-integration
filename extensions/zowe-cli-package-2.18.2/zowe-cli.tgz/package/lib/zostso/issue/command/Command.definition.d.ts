import { ICommandDefinition } from "@zowe/imperative";
export declare const CommandDefinition: ICommandDefinition;
//# sourceMappingURL=Command.definition.d.ts.map