import { ICommandDefinition } from "@zowe/imperative";
export declare const definition: ICommandDefinition;
//# sourceMappingURL=ZosTso.definition.d.ts.map