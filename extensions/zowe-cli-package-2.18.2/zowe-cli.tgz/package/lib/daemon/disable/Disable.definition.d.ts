import { ICommandDefinition } from "@zowe/imperative";
export declare const DisableCommand: ICommandDefinition;
//# sourceMappingURL=Disable.definition.d.ts.map