import { ICommandDefinition } from "@zowe/imperative";
export declare const RestartCommand: ICommandDefinition;
//# sourceMappingURL=Restart.definition.d.ts.map