import { ICommandDefinition } from "@zowe/imperative";
export declare const EnableCommand: ICommandDefinition;
//# sourceMappingURL=Enable.definition.d.ts.map