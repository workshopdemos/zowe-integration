import { ICommandDefinition } from "@zowe/imperative";
export declare const SshDefinition: ICommandDefinition;
//# sourceMappingURL=Ssh.definition.d.ts.map