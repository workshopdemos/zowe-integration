import { ICommandDefinition } from "@zowe/imperative";
export declare const definition: ICommandDefinition;
//# sourceMappingURL=ZosUss.definition.d.ts.map