import { ICommandDefinition } from "@zowe/imperative";
/**
 * List alias command definition containing its description, examples and/or options
 * @type {ICommandDefinition}
 */
export declare const AliasDefinition: ICommandDefinition;
//# sourceMappingURL=Alias.definition.d.ts.map