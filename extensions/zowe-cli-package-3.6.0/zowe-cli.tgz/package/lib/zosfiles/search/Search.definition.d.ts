import { ICommandDefinition } from "@zowe/imperative";
/**
 * Download group definition containing its description and children
 * @type {ICommandDefinition}
 */
export declare const SearchDefinition: ICommandDefinition;
//# sourceMappingURL=Search.definition.d.ts.map