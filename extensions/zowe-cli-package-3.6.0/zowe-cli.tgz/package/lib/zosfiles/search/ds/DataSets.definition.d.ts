import { ICommandDefinition } from "@zowe/imperative";
/**
 * List all data sets and members command definition containing its description, examples and/or options
 * @type {ICommandDefinition}
 */
export declare const DataSetsDefinition: ICommandDefinition;
//# sourceMappingURL=DataSets.definition.d.ts.map