/**
 * Class to contain  constants
 * @export
 * @class Constants
 */
export declare class Constants {
    /**
     * Custom log location to prevent logging to default folder based on the package name
     * @static
     * @memberof Constants
     */
    static readonly LOG_LOCATION = "logs/zowe.log";
    /**
     * Display name
     * @static
     * @memberof Constants
     */
    static readonly DISPLAY_NAME = "Zowe CLI";
    /**
     * Binary executable name
     * @static
     * @memberof Constants
     */
    static readonly BINARY_NAME = "zowe";
    /**
     *
     * Documentation link for the CLI
     * @static
     * @memberof Constants
     */
    static readonly DOCUMENTATION_LINK = "https://docs.zowe.org";
    /**
     *
     * Support link for zowe
     * @static
     * @memberof Constants
     */
    static readonly SUPPORT_LINK = "https://www.zowe.org";
    /**
     * Description of product
     * @static
     * @memberof Constants
     */
    static readonly DESCRIPTION: string;
    /**
     * Home environment variable
     * @static
     * @memberof Constants
     */
    static readonly HOME_ENV_KEY = "ZOWE_CLI_HOME";
    /**
     * Prefix for environmental variable settings used by Imperative
     * @static
     * @memberof Constants
     */
    static readonly ENV_PREFIX = "ZOWE";
    /**
     * Home directory
     * @static
     * @memberof Constants
     */
    static readonly HOME_DIR = "~/.zowe";
}
//# sourceMappingURL=Constants.d.ts.map