import { ICommandDefinition } from "@zowe/imperative";
export declare const SearchDefinition: ICommandDefinition;
//# sourceMappingURL=Search.definition.d.ts.map