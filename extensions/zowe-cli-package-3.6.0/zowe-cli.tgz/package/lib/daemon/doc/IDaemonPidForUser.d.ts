/**
 * Represents the content of the JSON file into which the Zowe Daemon
 * stores the process ID for a given user.
 */
export interface IDaemonPidForUser {
    user: string;
    pid: number;
    /**
     * Secret token that authenticates a daemon client as the owner of this
     * daemon. The daemon generates a fresh random token each time it starts
     * and writes it into this owner-only file. Because only the owner can read
     * the file, a client that can echo this token back has proven it is the
     * owner. The client sends it on every request (see {@link IDaemonResponse}).
     */
    token?: string;
}
//# sourceMappingURL=IDaemonPidForUser.d.ts.map