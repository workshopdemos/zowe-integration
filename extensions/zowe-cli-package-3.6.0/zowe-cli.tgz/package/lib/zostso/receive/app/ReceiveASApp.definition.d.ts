import { ICommandDefinition } from "@zowe/imperative";
export declare const ReceiveASApp: ICommandDefinition;
//# sourceMappingURL=ReceiveASApp.definition.d.ts.map