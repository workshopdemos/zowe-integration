import { ICommandDefinition } from "@zowe/imperative";
export declare const ReceiveCommand: ICommandDefinition;
//# sourceMappingURL=Receive.definition.d.ts.map