import { ICommandDefinition } from "@zowe/imperative";
export declare const SendASApp: ICommandDefinition;
//# sourceMappingURL=SendASApp.definition.d.ts.map