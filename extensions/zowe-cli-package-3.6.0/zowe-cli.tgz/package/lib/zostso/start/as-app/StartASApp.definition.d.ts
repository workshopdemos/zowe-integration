import { ICommandDefinition } from "@zowe/imperative";
export declare const StartASApp: ICommandDefinition;
//# sourceMappingURL=StartASApp.definition.d.ts.map